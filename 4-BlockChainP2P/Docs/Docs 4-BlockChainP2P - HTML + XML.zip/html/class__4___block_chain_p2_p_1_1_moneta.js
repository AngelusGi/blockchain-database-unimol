var class__4___block_chain_p2_p_1_1_moneta =
[
    [ "Moneta", "class__4___block_chain_p2_p_1_1_moneta.html#a5febd0833fc0a72aed9c24cb3bd4f0b8", null ],
    [ "TrasferisciMoneta", "class__4___block_chain_p2_p_1_1_moneta.html#aec13c2c8cf5615b3c2e331cd9ff07c71", null ],
    [ "IdAttualeProprietario", "class__4___block_chain_p2_p_1_1_moneta.html#a23ebcc32e2702624d15692e2b1ec8c7f", null ],
    [ "IdMoneta", "class__4___block_chain_p2_p_1_1_moneta.html#a6c462774dac32a2630914db86b8bac76", null ],
    [ "IdVecchioProprietario", "class__4___block_chain_p2_p_1_1_moneta.html#a9855afae13c4bcad6db88afeca329011", null ]
];