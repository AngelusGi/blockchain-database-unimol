var class__4___block_chain_p2_p_1_1_agv =
[
    [ "Matricola", "class__4___block_chain_p2_p_1_1_agv.html#a23bc2bcd94a061e4df65da78586211b4", null ],
    [ "Name", "class__4___block_chain_p2_p_1_1_agv.html#ae673b2cd706baebd0865d299152494c7", null ]
];