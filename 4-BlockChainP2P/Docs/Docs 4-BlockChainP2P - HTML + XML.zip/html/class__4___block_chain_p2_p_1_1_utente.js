var class__4___block_chain_p2_p_1_1_utente =
[
    [ "Utente", "class__4___block_chain_p2_p_1_1_utente.html#a1f06d6fb1355d056bc2ef7a7d024ed10", null ],
    [ "CreaPortafogli", "class__4___block_chain_p2_p_1_1_utente.html#a3ec9de5a0a3c160865871c12e1db37c8", null ],
    [ "IdUnivoco", "class__4___block_chain_p2_p_1_1_utente.html#a7b128019f9605a0dd9339a8a2bd21dcf", null ],
    [ "Nome", "class__4___block_chain_p2_p_1_1_utente.html#ad364e173ae0e330a59210c6b8f84c039", null ],
    [ "Saldo", "class__4___block_chain_p2_p_1_1_utente.html#af6154193a2e4986751aeb2ffa498fddb", null ]
];