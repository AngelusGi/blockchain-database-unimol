var class__4___block_chain_p2_p_1_1_gm =
[
    [ "Matricola", "class__4___block_chain_p2_p_1_1_gm.html#a82fb9b0f004b86d820b68e39957a05bc", null ],
    [ "Name", "class__4___block_chain_p2_p_1_1_gm.html#ace333137ddd077468d90a3dad2dd904f", null ]
];