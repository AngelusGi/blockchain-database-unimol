var class__4___block_chain_p2_p_1_1_ca =
[
    [ "Matricola", "class__4___block_chain_p2_p_1_1_ca.html#aa9f710848fa21ad24fd8525109a6fbe2", null ],
    [ "Name", "class__4___block_chain_p2_p_1_1_ca.html#ac8366aee7af102a57e083112977e41a4", null ]
];