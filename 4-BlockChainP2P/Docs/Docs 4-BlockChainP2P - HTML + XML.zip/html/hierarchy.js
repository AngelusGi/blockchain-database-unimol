var hierarchy =
[
    [ "_4_BlockChainP2P.Agv", "class__4___block_chain_p2_p_1_1_agv.html", null ],
    [ "_4_BlockChainP2P.Blocco", "class__4___block_chain_p2_p_1_1_blocco.html", null ],
    [ "_4_BlockChainP2P.BlockChain", "class__4___block_chain_p2_p_1_1_block_chain.html", null ],
    [ "_4_BlockChainP2P.Ca", "class__4___block_chain_p2_p_1_1_ca.html", null ],
    [ "_4_BlockChainP2P.Candidati", "class__4___block_chain_p2_p_1_1_candidati.html", null ],
    [ "_4_BlockChainP2P.CandidatiJson", "class__4___block_chain_p2_p_1_1_candidati_json.html", null ],
    [ "_4_BlockChainP2P.SmartContract.Clause", "class__4___block_chain_p2_p_1_1_smart_contract_1_1_clause.html", null ],
    [ "_4_BlockChainP2P.Gm", "class__4___block_chain_p2_p_1_1_gm.html", null ],
    [ "_4_BlockChainP2P.Menu", "class__4___block_chain_p2_p_1_1_menu.html", null ],
    [ "_4_BlockChainP2P.Moneta", "class__4___block_chain_p2_p_1_1_moneta.html", null ],
    [ "_4_BlockChainP2P.P2PClient", "class__4___block_chain_p2_p_1_1_p2_p_client.html", null ],
    [ "_4_BlockChainP2P.Professor", "class__4___block_chain_p2_p_1_1_professor.html", null ],
    [ "_4_BlockChainP2P.Program", "class__4___block_chain_p2_p_1_1_program.html", null ],
    [ "_4_BlockChainP2P.SmartContract.Properties", "class__4___block_chain_p2_p_1_1_smart_contract_1_1_properties.html", null ],
    [ "_4_BlockChainP2P.Properties", "class__4___block_chain_p2_p_1_1_properties.html", null ],
    [ "_4_BlockChainP2P.SmartContract.Revision", "class__4___block_chain_p2_p_1_1_smart_contract_1_1_revision.html", null ],
    [ "_4_BlockChainP2P.Transazione", "class__4___block_chain_p2_p_1_1_transazione.html", null ],
    [ "_4_BlockChainP2P.Utente", "class__4___block_chain_p2_p_1_1_utente.html", null ],
    [ "_4_BlockChainP2P.SmartContract.ValidationData", "class__4___block_chain_p2_p_1_1_smart_contract_1_1_validation_data.html", null ],
    [ "WebSocketBehavior", null, [
      [ "_4_BlockChainP2P.P2PServer", "class__4___block_chain_p2_p_1_1_p2_p_server.html", null ]
    ] ]
];