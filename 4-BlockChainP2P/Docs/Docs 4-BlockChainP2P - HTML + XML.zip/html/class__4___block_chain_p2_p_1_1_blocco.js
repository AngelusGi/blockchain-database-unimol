var class__4___block_chain_p2_p_1_1_blocco =
[
    [ "Blocco", "class__4___block_chain_p2_p_1_1_blocco.html#aa6ae39d80fda607b08d3333754125878", null ],
    [ "CalcolaHash", "class__4___block_chain_p2_p_1_1_blocco.html#a7d28642fd82aa844b5a678c5c5cd8958", null ],
    [ "Mina", "class__4___block_chain_p2_p_1_1_blocco.html#a1893c7982804f983a7d68967af6db3f2", null ],
    [ "DataOra", "class__4___block_chain_p2_p_1_1_blocco.html#ade1af497f2e034914005ac91706fd475", null ],
    [ "HashBloccoCorrente", "class__4___block_chain_p2_p_1_1_blocco.html#a40d62dd757a998424a3a7624d1ed9adf", null ],
    [ "HashPrecedente", "class__4___block_chain_p2_p_1_1_blocco.html#a95b4b0447ec9cc5259998fdb202790af", null ],
    [ "Indice", "class__4___block_chain_p2_p_1_1_blocco.html#adcfbaf555377cf48b11862ed968c4202", null ],
    [ "Nonce", "class__4___block_chain_p2_p_1_1_blocco.html#aebe7f0c519b3a8a95f8133cdba7c8a81", null ],
    [ "Transazioni", "class__4___block_chain_p2_p_1_1_blocco.html#ae5b3546cfcae9b5cf424286a33c8c685", null ]
];