var class__4___block_chain_p2_p_1_1_candidati_json =
[
    [ "Properties", "class__4___block_chain_p2_p_1_1_candidati_json.html#a30e6b022da8485bdff6cc02bfa69bcd0", null ]
];