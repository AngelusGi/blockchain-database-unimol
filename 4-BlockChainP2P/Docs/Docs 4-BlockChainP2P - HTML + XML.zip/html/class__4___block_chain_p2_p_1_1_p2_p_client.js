var class__4___block_chain_p2_p_1_1_p2_p_client =
[
    [ "Broadcast", "class__4___block_chain_p2_p_1_1_p2_p_client.html#a042b49c215facef3cdabeacea97afb1b", null ],
    [ "Close", "class__4___block_chain_p2_p_1_1_p2_p_client.html#a8b5122e62793d443141e892f25a3a5f8", null ],
    [ "Connetti", "class__4___block_chain_p2_p_1_1_p2_p_client.html#aa1c20c29100e0cb53c03881f80c7c083", null ],
    [ "GetServers", "class__4___block_chain_p2_p_1_1_p2_p_client.html#a2398b73b3a0644140876e1bb5763f025", null ],
    [ "Send", "class__4___block_chain_p2_p_1_1_p2_p_client.html#a05aeb8a6a0d6a9feecd694436752c3bb", null ]
];