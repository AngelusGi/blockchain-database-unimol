var class__4___block_chain_p2_p_1_1_properties =
[
    [ "Agv", "class__4___block_chain_p2_p_1_1_properties.html#a6c55bc54800a3ceed342f2cbdc423685", null ],
    [ "Ca", "class__4___block_chain_p2_p_1_1_properties.html#a31eeb1456a8511239b8fc46f0e11a681", null ],
    [ "Gm", "class__4___block_chain_p2_p_1_1_properties.html#acc98f4501f46a30ada5010aa7c25f71d", null ],
    [ "Professor", "class__4___block_chain_p2_p_1_1_properties.html#aa39ae05e5682619452ebdbf69d398681", null ]
];