var class__4___block_chain_p2_p_1_1_block_chain =
[
    [ "BlockChain", "class__4___block_chain_p2_p_1_1_block_chain.html#ab7750e9dcf732bb5c0b306b3c76f563c", null ],
    [ "AggiornaBilancio", "class__4___block_chain_p2_p_1_1_block_chain.html#a5c416106e3eec6195b659844f7fe2432", null ],
    [ "AggiornaSaldoUtenti", "class__4___block_chain_p2_p_1_1_block_chain.html#ae1a3e3f0f9a27a5ff76958c7e7844f8f", null ],
    [ "AggiungiBlocco", "class__4___block_chain_p2_p_1_1_block_chain.html#a49f1a778cd99d70158258280a1f39ffa", null ],
    [ "AggiungiBloccoIniziale", "class__4___block_chain_p2_p_1_1_block_chain.html#a71478e3c391aafb2450c494128afc51b", null ],
    [ "CreaBloccoIniziale", "class__4___block_chain_p2_p_1_1_block_chain.html#a84a07340caf4099d99be690d74d25cb2", null ],
    [ "CreaTransazione", "class__4___block_chain_p2_p_1_1_block_chain.html#a36abd523a418b542e7a9ecdbb56d11d7", null ],
    [ "GetUltimoBlocco", "class__4___block_chain_p2_p_1_1_block_chain.html#a95435965b742444658525c1757314a30", null ],
    [ "InizializzaCatena", "class__4___block_chain_p2_p_1_1_block_chain.html#aea2627b70277e5f42679e779c8ed3117", null ],
    [ "IsValido", "class__4___block_chain_p2_p_1_1_block_chain.html#a72609fae1e32e0cf6b3eb0c92b035a77", null ],
    [ "MinaTransazioni", "class__4___block_chain_p2_p_1_1_block_chain.html#a7af1d26e9b426e45fe4aac22e42c5156", null ],
    [ "RicercaUtente", "class__4___block_chain_p2_p_1_1_block_chain.html#ae1a7a8559ee87b769cb872af81519685", null ],
    [ "RicercaUtente", "class__4___block_chain_p2_p_1_1_block_chain.html#a5efedcc461f0c012165d6d67c2b8db7f", null ],
    [ "VerificaUtente", "class__4___block_chain_p2_p_1_1_block_chain.html#a63e9badc3c7c162d088c21fde333ea56", null ],
    [ "TransazioniInAttesa", "class__4___block_chain_p2_p_1_1_block_chain.html#a9bf15ec9223c0e4d2da39cccea213230", null ],
    [ "Catena", "class__4___block_chain_p2_p_1_1_block_chain.html#aa3ba54aea8aa86a08df5c41bfe3fe892", null ],
    [ "Difficoltà", "class__4___block_chain_p2_p_1_1_block_chain.html#a04f46b57c5a7d066562eef4f92cef8dc", null ],
    [ "Utenti", "class__4___block_chain_p2_p_1_1_block_chain.html#a6155eff074641d1c32284f6c50f0f26f", null ]
];