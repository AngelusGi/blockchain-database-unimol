var searchData=
[
  ['validationdata',['ValidationData',['../class__4___block_chain_p2_p_1_1_smart_contract_1_1_validation_data.html',1,'_4_BlockChainP2P::SmartContract']]],
  ['valore',['Valore',['../class__4___block_chain_p2_p_1_1_transazione.html#af1c3c934520f566437ae21faaf956fee',1,'_4_BlockChainP2P::Transazione']]],
  ['verificautente',['VerificaUtente',['../class__4___block_chain_p2_p_1_1_block_chain.html#a63e9badc3c7c162d088c21fde333ea56',1,'_4_BlockChainP2P::BlockChain']]]
];
