var searchData=
[
  ['transazioniinattesa',['TransazioniInAttesa',['../class__4___block_chain_p2_p_1_1_block_chain.html#a9bf15ec9223c0e4d2da39cccea213230',1,'_4_BlockChainP2P::BlockChain']]]
];
