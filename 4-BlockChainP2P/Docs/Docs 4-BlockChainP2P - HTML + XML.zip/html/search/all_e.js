var searchData=
[
  ['utente',['Utente',['../class__4___block_chain_p2_p_1_1_utente.html',1,'_4_BlockChainP2P.Utente'],['../class__4___block_chain_p2_p_1_1_utente.html#a1f06d6fb1355d056bc2ef7a7d024ed10',1,'_4_BlockChainP2P.Utente.Utente()']]],
  ['utenti',['Utenti',['../class__4___block_chain_p2_p_1_1_block_chain.html#a6155eff074641d1c32284f6c50f0f26f',1,'_4_BlockChainP2P::BlockChain']]]
];
