var searchData=
[
  ['nome',['Nome',['../class__4___block_chain_p2_p_1_1_utente.html#ad364e173ae0e330a59210c6b8f84c039',1,'_4_BlockChainP2P::Utente']]]
];
