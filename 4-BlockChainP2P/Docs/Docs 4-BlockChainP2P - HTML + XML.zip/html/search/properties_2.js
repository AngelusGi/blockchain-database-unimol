var searchData=
[
  ['iddestinatario',['IdDestinatario',['../class__4___block_chain_p2_p_1_1_transazione.html#a0a1402926b6361881c93f2fa3dacd877',1,'_4_BlockChainP2P::Transazione']]],
  ['idmittente',['IdMittente',['../class__4___block_chain_p2_p_1_1_transazione.html#a2c12bab8ae954170808fcabcb1bc6a99',1,'_4_BlockChainP2P::Transazione']]],
  ['idmoneta',['IdMoneta',['../class__4___block_chain_p2_p_1_1_moneta.html#a6c462774dac32a2630914db86b8bac76',1,'_4_BlockChainP2P::Moneta']]],
  ['idunivoco',['IdUnivoco',['../class__4___block_chain_p2_p_1_1_utente.html#a7b128019f9605a0dd9339a8a2bd21dcf',1,'_4_BlockChainP2P::Utente']]],
  ['indice',['Indice',['../class__4___block_chain_p2_p_1_1_blocco.html#adcfbaf555377cf48b11862ed968c4202',1,'_4_BlockChainP2P::Blocco']]]
];
