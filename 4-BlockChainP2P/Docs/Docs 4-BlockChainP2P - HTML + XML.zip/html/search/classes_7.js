var searchData=
[
  ['transazione',['Transazione',['../class__4___block_chain_p2_p_1_1_transazione.html',1,'_4_BlockChainP2P']]]
];
