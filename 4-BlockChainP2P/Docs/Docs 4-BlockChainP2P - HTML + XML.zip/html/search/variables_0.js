var searchData=
[
  ['ricompensa',['Ricompensa',['../class__4___block_chain_p2_p_1_1_block_chain.html#adec20ceead9755cb5060488e67163015',1,'_4_BlockChainP2P::BlockChain']]]
];
