var searchData=
[
  ['isvalido',['IsValido',['../class__4___block_chain_p2_p_1_1_block_chain.html#a72609fae1e32e0cf6b3eb0c92b035a77',1,'_4_BlockChainP2P::BlockChain']]]
];
