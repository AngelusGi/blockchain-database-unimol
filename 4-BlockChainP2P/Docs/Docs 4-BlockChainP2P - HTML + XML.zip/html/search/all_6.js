var searchData=
[
  ['hashbloccocorrente',['HashBloccoCorrente',['../class__4___block_chain_p2_p_1_1_blocco.html#a40d62dd757a998424a3a7624d1ed9adf',1,'_4_BlockChainP2P::Blocco']]],
  ['hashprecedente',['HashPrecedente',['../class__4___block_chain_p2_p_1_1_blocco.html#a95b4b0447ec9cc5259998fdb202790af',1,'_4_BlockChainP2P::Blocco']]]
];
