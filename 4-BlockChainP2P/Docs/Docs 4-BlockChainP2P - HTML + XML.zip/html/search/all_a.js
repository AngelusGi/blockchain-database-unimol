var searchData=
[
  ['opzionimenu',['OpzioniMenu',['../namespace__4___block_chain_p2_p.html#a977a96907fdd6ed2fa1ef3a1eeff94c3',1,'_4_BlockChainP2P']]]
];
