var searchData=
[
  ['blocco',['Blocco',['../class__4___block_chain_p2_p_1_1_blocco.html',1,'_4_BlockChainP2P']]],
  ['blockchain',['BlockChain',['../class__4___block_chain_p2_p_1_1_block_chain.html',1,'_4_BlockChainP2P']]]
];
