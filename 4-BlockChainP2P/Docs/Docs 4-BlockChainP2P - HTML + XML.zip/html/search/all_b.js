var searchData=
[
  ['revision',['Revision',['../class__4___block_chain_p2_p_1_1_smart_contract_1_1_revision.html',1,'_4_BlockChainP2P::SmartContract']]],
  ['ricercautente',['RicercaUtente',['../class__4___block_chain_p2_p_1_1_block_chain.html#ae1a7a8559ee87b769cb872af81519685',1,'_4_BlockChainP2P.BlockChain.RicercaUtente(string nome)'],['../class__4___block_chain_p2_p_1_1_block_chain.html#a5efedcc461f0c012165d6d67c2b8db7f',1,'_4_BlockChainP2P.BlockChain.RicercaUtente(int? idUtente)']]],
  ['ricompensa',['Ricompensa',['../class__4___block_chain_p2_p_1_1_block_chain.html#adec20ceead9755cb5060488e67163015',1,'_4_BlockChainP2P::BlockChain']]]
];
