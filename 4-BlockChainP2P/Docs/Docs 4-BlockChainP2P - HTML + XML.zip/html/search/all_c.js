var searchData=
[
  ['transazione',['Transazione',['../class__4___block_chain_p2_p_1_1_transazione.html',1,'_4_BlockChainP2P']]],
  ['transazioniinattesa',['TransazioniInAttesa',['../class__4___block_chain_p2_p_1_1_block_chain.html#a9bf15ec9223c0e4d2da39cccea213230',1,'_4_BlockChainP2P::BlockChain']]],
  ['trasferiscimoneta',['TrasferisciMoneta',['../class__4___block_chain_p2_p_1_1_moneta.html#aec13c2c8cf5615b3c2e331cd9ff07c71',1,'_4_BlockChainP2P::Moneta']]]
];
