var searchData=
[
  ['ca',['Ca',['../class__4___block_chain_p2_p_1_1_ca.html',1,'_4_BlockChainP2P']]],
  ['calcolahash',['CalcolaHash',['../class__4___block_chain_p2_p_1_1_blocco.html#a7d28642fd82aa844b5a678c5c5cd8958',1,'_4_BlockChainP2P::Blocco']]],
  ['candidati',['Candidati',['../class__4___block_chain_p2_p_1_1_candidati.html',1,'_4_BlockChainP2P']]],
  ['candidatijson',['CandidatiJson',['../class__4___block_chain_p2_p_1_1_candidati_json.html',1,'_4_BlockChainP2P']]],
  ['clause',['Clause',['../class__4___block_chain_p2_p_1_1_smart_contract_1_1_clause.html',1,'_4_BlockChainP2P::SmartContract']]],
  ['creabloccoiniziale',['CreaBloccoIniziale',['../class__4___block_chain_p2_p_1_1_block_chain.html#a84a07340caf4099d99be690d74d25cb2',1,'_4_BlockChainP2P::BlockChain']]],
  ['creaportafogli',['CreaPortafogli',['../class__4___block_chain_p2_p_1_1_utente.html#a3ec9de5a0a3c160865871c12e1db37c8',1,'_4_BlockChainP2P::Utente']]]
];
