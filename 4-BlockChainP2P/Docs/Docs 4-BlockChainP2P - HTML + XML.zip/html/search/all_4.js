var searchData=
[
  ['dataora',['DataOra',['../class__4___block_chain_p2_p_1_1_blocco.html#ade1af497f2e034914005ac91706fd475',1,'_4_BlockChainP2P::Blocco']]],
  ['difficoltà',['Difficoltà',['../class__4___block_chain_p2_p_1_1_block_chain.html#a04f46b57c5a7d066562eef4f92cef8dc',1,'_4_BlockChainP2P::BlockChain']]]
];
