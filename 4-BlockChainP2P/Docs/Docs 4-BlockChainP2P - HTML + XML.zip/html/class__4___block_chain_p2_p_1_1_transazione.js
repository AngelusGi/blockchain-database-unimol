var class__4___block_chain_p2_p_1_1_transazione =
[
    [ "Transazione", "class__4___block_chain_p2_p_1_1_transazione.html#a431ff9d61a3f22380ce3a42e918667bc", null ],
    [ "Contabilizzata", "class__4___block_chain_p2_p_1_1_transazione.html#a455534fc9ba779e085f602fa9f7acc1b", null ],
    [ "IdDestinatario", "class__4___block_chain_p2_p_1_1_transazione.html#a0a1402926b6361881c93f2fa3dacd877", null ],
    [ "IdMittente", "class__4___block_chain_p2_p_1_1_transazione.html#a2c12bab8ae954170808fcabcb1bc6a99", null ],
    [ "Valore", "class__4___block_chain_p2_p_1_1_transazione.html#af1c3c934520f566437ae21faaf956fee", null ]
];