var namespace__4___block_chain_p2_p =
[
    [ "Agv", "class__4___block_chain_p2_p_1_1_agv.html", "class__4___block_chain_p2_p_1_1_agv" ],
    [ "Blocco", "class__4___block_chain_p2_p_1_1_blocco.html", "class__4___block_chain_p2_p_1_1_blocco" ],
    [ "BlockChain", "class__4___block_chain_p2_p_1_1_block_chain.html", "class__4___block_chain_p2_p_1_1_block_chain" ],
    [ "Ca", "class__4___block_chain_p2_p_1_1_ca.html", "class__4___block_chain_p2_p_1_1_ca" ],
    [ "Candidati", "class__4___block_chain_p2_p_1_1_candidati.html", null ],
    [ "CandidatiJson", "class__4___block_chain_p2_p_1_1_candidati_json.html", "class__4___block_chain_p2_p_1_1_candidati_json" ],
    [ "Gm", "class__4___block_chain_p2_p_1_1_gm.html", "class__4___block_chain_p2_p_1_1_gm" ],
    [ "Menu", "class__4___block_chain_p2_p_1_1_menu.html", "class__4___block_chain_p2_p_1_1_menu" ],
    [ "Moneta", "class__4___block_chain_p2_p_1_1_moneta.html", "class__4___block_chain_p2_p_1_1_moneta" ],
    [ "P2PClient", "class__4___block_chain_p2_p_1_1_p2_p_client.html", "class__4___block_chain_p2_p_1_1_p2_p_client" ],
    [ "P2PServer", "class__4___block_chain_p2_p_1_1_p2_p_server.html", "class__4___block_chain_p2_p_1_1_p2_p_server" ],
    [ "Professor", "class__4___block_chain_p2_p_1_1_professor.html", "class__4___block_chain_p2_p_1_1_professor" ],
    [ "Program", "class__4___block_chain_p2_p_1_1_program.html", null ],
    [ "Properties", "class__4___block_chain_p2_p_1_1_properties.html", "class__4___block_chain_p2_p_1_1_properties" ],
    [ "Transazione", "class__4___block_chain_p2_p_1_1_transazione.html", "class__4___block_chain_p2_p_1_1_transazione" ],
    [ "Utente", "class__4___block_chain_p2_p_1_1_utente.html", "class__4___block_chain_p2_p_1_1_utente" ]
];