var class__3___block_chain_menu_1_1_block_chain =
[
    [ "BlockChain", "class__3___block_chain_menu_1_1_block_chain.html#a8adc51cfb9f2f983e73964cc88a962cf", null ],
    [ "AggiornaBilancio", "class__3___block_chain_menu_1_1_block_chain.html#a6ddd80019bdc8d23e648753ffd78a1c9", null ],
    [ "AggiornaSaldoUtenti", "class__3___block_chain_menu_1_1_block_chain.html#a3f65a6234ebbd1ce41107a825eaa807a", null ],
    [ "AggiungiBlocco", "class__3___block_chain_menu_1_1_block_chain.html#aa1d5f7faa5dee540c3be1529383725c4", null ],
    [ "AggiungiBloccoIniziale", "class__3___block_chain_menu_1_1_block_chain.html#a86b9fdcb101bec19084738c185852486", null ],
    [ "CreaBloccoIniziale", "class__3___block_chain_menu_1_1_block_chain.html#a35f9e42dd9d6bd0198abf89b7b737acf", null ],
    [ "CreaTransazione", "class__3___block_chain_menu_1_1_block_chain.html#ae67adbf0a4872de6aebf28df6d1b5395", null ],
    [ "GetUltimoBlocco", "class__3___block_chain_menu_1_1_block_chain.html#a1d038c3edb56d32ae3cbc13ed5bfc483", null ],
    [ "InizializzaCatena", "class__3___block_chain_menu_1_1_block_chain.html#a460beaced8b88080b309a8016e9f93ec", null ],
    [ "IsValido", "class__3___block_chain_menu_1_1_block_chain.html#afea654e85bd242c1d8a38596a66ca4da", null ],
    [ "MinaTransazioni", "class__3___block_chain_menu_1_1_block_chain.html#a4c6ad6b4f911a2e7bbd4323b2384b8c0", null ],
    [ "RicercaUtente", "class__3___block_chain_menu_1_1_block_chain.html#a52865fda6c6a80bd96e11aa568c43b21", null ],
    [ "RicercaUtente", "class__3___block_chain_menu_1_1_block_chain.html#ac08bea4dc3b79e5e64a6119a993541cd", null ],
    [ "VerificaUtente", "class__3___block_chain_menu_1_1_block_chain.html#aee283a97a5024b2e60bca190ccfc3426", null ],
    [ "TransazioniInAttesa", "class__3___block_chain_menu_1_1_block_chain.html#a404fd655b21a03a3d17221804d3aaa2a", null ],
    [ "Catena", "class__3___block_chain_menu_1_1_block_chain.html#a3c223f669021fb102be6fb6e76fc757f", null ],
    [ "Difficoltà", "class__3___block_chain_menu_1_1_block_chain.html#a31303b2253c8ce939d40048d6f656478", null ],
    [ "Utenti", "class__3___block_chain_menu_1_1_block_chain.html#a84803ca4c06905dc9b784a730d2d59eb", null ]
];