var class__3___block_chain_menu_1_1_candidati_json =
[
    [ "Properties", "class__3___block_chain_menu_1_1_candidati_json.html#afe5643da2dd306fa029461e1489b313c", null ]
];