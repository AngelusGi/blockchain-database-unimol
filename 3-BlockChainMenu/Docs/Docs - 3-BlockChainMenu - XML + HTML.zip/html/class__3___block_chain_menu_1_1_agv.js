var class__3___block_chain_menu_1_1_agv =
[
    [ "Matricola", "class__3___block_chain_menu_1_1_agv.html#a08f54da957d3bd8643a60bc18f16e992", null ],
    [ "Name", "class__3___block_chain_menu_1_1_agv.html#a0aff9865822964db0eb87ae8713788ce", null ]
];