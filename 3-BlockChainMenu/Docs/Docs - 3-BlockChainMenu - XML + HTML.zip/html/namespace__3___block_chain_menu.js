var namespace__3___block_chain_menu =
[
    [ "Agv", "class__3___block_chain_menu_1_1_agv.html", "class__3___block_chain_menu_1_1_agv" ],
    [ "Blocco", "class__3___block_chain_menu_1_1_blocco.html", "class__3___block_chain_menu_1_1_blocco" ],
    [ "BlockChain", "class__3___block_chain_menu_1_1_block_chain.html", "class__3___block_chain_menu_1_1_block_chain" ],
    [ "Ca", "class__3___block_chain_menu_1_1_ca.html", "class__3___block_chain_menu_1_1_ca" ],
    [ "Candidati", "class__3___block_chain_menu_1_1_candidati.html", null ],
    [ "CandidatiJson", "class__3___block_chain_menu_1_1_candidati_json.html", "class__3___block_chain_menu_1_1_candidati_json" ],
    [ "Gm", "class__3___block_chain_menu_1_1_gm.html", "class__3___block_chain_menu_1_1_gm" ],
    [ "Menu", "class__3___block_chain_menu_1_1_menu.html", "class__3___block_chain_menu_1_1_menu" ],
    [ "Moneta", "class__3___block_chain_menu_1_1_moneta.html", "class__3___block_chain_menu_1_1_moneta" ],
    [ "Professor", "class__3___block_chain_menu_1_1_professor.html", "class__3___block_chain_menu_1_1_professor" ],
    [ "Program", "class__3___block_chain_menu_1_1_program.html", null ],
    [ "Properties", "class__3___block_chain_menu_1_1_properties.html", "class__3___block_chain_menu_1_1_properties" ],
    [ "Transazione", "class__3___block_chain_menu_1_1_transazione.html", "class__3___block_chain_menu_1_1_transazione" ],
    [ "Utente", "class__3___block_chain_menu_1_1_utente.html", "class__3___block_chain_menu_1_1_utente" ]
];