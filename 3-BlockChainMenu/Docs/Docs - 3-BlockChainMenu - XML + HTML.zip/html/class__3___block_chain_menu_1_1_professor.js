var class__3___block_chain_menu_1_1_professor =
[
    [ "Name", "class__3___block_chain_menu_1_1_professor.html#afbdfb544fb4c9ae907ab09b561c1de41", null ]
];