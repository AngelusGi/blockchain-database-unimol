var class__3___block_chain_menu_1_1_ca =
[
    [ "Matricola", "class__3___block_chain_menu_1_1_ca.html#a316fea5da551f62cdbaa7073a98427c0", null ],
    [ "Name", "class__3___block_chain_menu_1_1_ca.html#a8352835cdac2dac99ddcafaeaf7498bf", null ]
];