var class__3___block_chain_menu_1_1_transazione =
[
    [ "Transazione", "class__3___block_chain_menu_1_1_transazione.html#af3f0abdb34474f12a3f5bb2ba40fc539", null ],
    [ "Contabilizzata", "class__3___block_chain_menu_1_1_transazione.html#a63b54d8ef080dbdc561ba2602a6afbf8", null ],
    [ "IdDestinatario", "class__3___block_chain_menu_1_1_transazione.html#a0d7d08a7363a550a45fba73c4c072662", null ],
    [ "IdMittente", "class__3___block_chain_menu_1_1_transazione.html#a5a815daa379d9dc7bba109a81dbc3a36", null ],
    [ "Valore", "class__3___block_chain_menu_1_1_transazione.html#a9b2a8450d377b7387c6b57800fb1ec02", null ]
];