var class__3___block_chain_menu_1_1_gm =
[
    [ "Matricola", "class__3___block_chain_menu_1_1_gm.html#ad81dba755e3c36d8b8ede599c88d0fcf", null ],
    [ "Name", "class__3___block_chain_menu_1_1_gm.html#a2a569bcf8e0767e9b6fb9509fab9a484", null ]
];