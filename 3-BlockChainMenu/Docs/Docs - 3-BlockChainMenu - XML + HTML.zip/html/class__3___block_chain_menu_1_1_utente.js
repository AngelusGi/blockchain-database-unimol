var class__3___block_chain_menu_1_1_utente =
[
    [ "Utente", "class__3___block_chain_menu_1_1_utente.html#a022f5272745c01f7d2e3e7a171f69bff", null ],
    [ "CreaPortafogli", "class__3___block_chain_menu_1_1_utente.html#a7925b5a7ac61585d764e6fa439d932d0", null ],
    [ "IdUnivoco", "class__3___block_chain_menu_1_1_utente.html#a1e174bcf6728e7df4fd06b41f21574f8", null ],
    [ "Nome", "class__3___block_chain_menu_1_1_utente.html#abe0b3897d9b76130aadf2bd97ca805e8", null ],
    [ "Saldo", "class__3___block_chain_menu_1_1_utente.html#a1745f1432a9c76c1ba43117c95c74f7e", null ]
];