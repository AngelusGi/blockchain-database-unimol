var searchData=
[
  ['utente',['Utente',['../class__3___block_chain_menu_1_1_utente.html#a022f5272745c01f7d2e3e7a171f69bff',1,'_3_BlockChainMenu::Utente']]]
];
