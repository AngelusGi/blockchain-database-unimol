var searchData=
[
  ['verificautente',['VerificaUtente',['../class__3___block_chain_menu_1_1_block_chain.html#aee283a97a5024b2e60bca190ccfc3426',1,'_3_BlockChainMenu::BlockChain']]]
];
