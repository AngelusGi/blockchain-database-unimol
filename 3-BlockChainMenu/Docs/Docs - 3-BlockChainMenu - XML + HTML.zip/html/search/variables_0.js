var searchData=
[
  ['ricompensa',['Ricompensa',['../class__3___block_chain_menu_1_1_block_chain.html#af55e8e38b2d55aebed576fb7f655011b',1,'_3_BlockChainMenu::BlockChain']]]
];
