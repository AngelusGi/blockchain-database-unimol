var searchData=
[
  ['utente',['Utente',['../class__3___block_chain_menu_1_1_utente.html',1,'_3_BlockChainMenu']]]
];
