var searchData=
[
  ['ca',['Ca',['../class__3___block_chain_menu_1_1_ca.html',1,'_3_BlockChainMenu']]],
  ['candidati',['Candidati',['../class__3___block_chain_menu_1_1_candidati.html',1,'_3_BlockChainMenu']]],
  ['candidatijson',['CandidatiJson',['../class__3___block_chain_menu_1_1_candidati_json.html',1,'_3_BlockChainMenu']]],
  ['clause',['Clause',['../class__3___block_chain_menu_1_1_smart_contract_1_1_clause.html',1,'_3_BlockChainMenu::SmartContract']]],
  ['contrattojson',['ContrattoJson',['../class__3___block_chain_menu_1_1_smart_contract_1_1_contratto_json.html',1,'_3_BlockChainMenu::SmartContract']]]
];
