var searchData=
[
  ['iddestinatario',['IdDestinatario',['../class__3___block_chain_menu_1_1_transazione.html#a0d7d08a7363a550a45fba73c4c072662',1,'_3_BlockChainMenu::Transazione']]],
  ['idmittente',['IdMittente',['../class__3___block_chain_menu_1_1_transazione.html#a5a815daa379d9dc7bba109a81dbc3a36',1,'_3_BlockChainMenu::Transazione']]],
  ['idmoneta',['IdMoneta',['../class__3___block_chain_menu_1_1_moneta.html#a7f16c915c288cf12c0cc9ad599b7979e',1,'_3_BlockChainMenu::Moneta']]],
  ['idunivoco',['IdUnivoco',['../class__3___block_chain_menu_1_1_utente.html#a1e174bcf6728e7df4fd06b41f21574f8',1,'_3_BlockChainMenu::Utente']]],
  ['indice',['Indice',['../class__3___block_chain_menu_1_1_blocco.html#ad00aa9549d4ad8b15c7f407df46274d8',1,'_3_BlockChainMenu::Blocco']]]
];
