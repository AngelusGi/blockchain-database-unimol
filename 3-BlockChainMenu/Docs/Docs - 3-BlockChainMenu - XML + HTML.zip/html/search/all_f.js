var searchData=
[
  ['validationdata',['Validationdata',['../class__3___block_chain_menu_1_1_smart_contract_1_1_validationdata.html',1,'_3_BlockChainMenu::SmartContract']]],
  ['valore',['Valore',['../class__3___block_chain_menu_1_1_transazione.html#a9b2a8450d377b7387c6b57800fb1ec02',1,'_3_BlockChainMenu::Transazione']]],
  ['verificautente',['VerificaUtente',['../class__3___block_chain_menu_1_1_block_chain.html#aee283a97a5024b2e60bca190ccfc3426',1,'_3_BlockChainMenu::BlockChain']]]
];
