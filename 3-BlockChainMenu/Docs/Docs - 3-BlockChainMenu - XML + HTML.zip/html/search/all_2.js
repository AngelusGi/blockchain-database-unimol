var searchData=
[
  ['blocco',['Blocco',['../class__3___block_chain_menu_1_1_blocco.html',1,'_3_BlockChainMenu']]],
  ['blockchain',['BlockChain',['../class__3___block_chain_menu_1_1_block_chain.html',1,'_3_BlockChainMenu']]]
];
