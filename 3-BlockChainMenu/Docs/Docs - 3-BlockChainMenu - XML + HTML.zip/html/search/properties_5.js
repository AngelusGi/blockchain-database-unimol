var searchData=
[
  ['valore',['Valore',['../class__3___block_chain_menu_1_1_transazione.html#a9b2a8450d377b7387c6b57800fb1ec02',1,'_3_BlockChainMenu::Transazione']]]
];
