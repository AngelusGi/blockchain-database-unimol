var searchData=
[
  ['mina',['Mina',['../class__3___block_chain_menu_1_1_blocco.html#ab40348816acbbe4b2e7197eab6c700f4',1,'_3_BlockChainMenu::Blocco']]],
  ['minatransazioni',['MinaTransazioni',['../class__3___block_chain_menu_1_1_block_chain.html#a4c6ad6b4f911a2e7bbd4323b2384b8c0',1,'_3_BlockChainMenu::BlockChain']]],
  ['mostracanidati',['MostraCanidati',['../class__3___block_chain_menu_1_1_candidati.html#aab258794157e8c2ed866469bb96a0a4d',1,'_3_BlockChainMenu::Candidati']]]
];
