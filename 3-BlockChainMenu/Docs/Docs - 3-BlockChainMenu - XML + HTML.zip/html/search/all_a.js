var searchData=
[
  ['opzionimenu',['OpzioniMenu',['../namespace__3___block_chain_menu.html#ad9fa765d62547301e90ad02fb9c89bee',1,'_3_BlockChainMenu']]]
];
