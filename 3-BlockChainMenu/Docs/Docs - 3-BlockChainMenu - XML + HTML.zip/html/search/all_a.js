var searchData=
[
  ['professor',['Professor',['../class__3___block_chain_menu_1_1_professor.html',1,'_3_BlockChainMenu']]],
  ['program',['Program',['../class__3___block_chain_menu_1_1_program.html',1,'_3_BlockChainMenu']]],
  ['properties',['Properties',['../class__3___block_chain_menu_1_1_properties.html',1,'_3_BlockChainMenu.Properties'],['../class__3___block_chain_menu_1_1_smart_contract_1_1_properties.html',1,'_3_BlockChainMenu.SmartContract.Properties']]]
];
