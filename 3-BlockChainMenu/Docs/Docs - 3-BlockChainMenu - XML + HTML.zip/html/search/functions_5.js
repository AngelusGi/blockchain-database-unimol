var searchData=
[
  ['trasferiscimoneta',['TrasferisciMoneta',['../class__3___block_chain_menu_1_1_moneta.html#a4f7b5335eca94f3af1c24dd2f6a98385',1,'_3_BlockChainMenu::Moneta']]]
];
