var searchData=
[
  ['utenti',['Utenti',['../class__3___block_chain_menu_1_1_block_chain.html#a84803ca4c06905dc9b784a730d2d59eb',1,'_3_BlockChainMenu::BlockChain']]]
];
