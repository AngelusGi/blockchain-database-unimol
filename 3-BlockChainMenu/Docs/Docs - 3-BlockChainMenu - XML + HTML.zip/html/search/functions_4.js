var searchData=
[
  ['ricercautente',['RicercaUtente',['../class__3___block_chain_menu_1_1_block_chain.html#a52865fda6c6a80bd96e11aa568c43b21',1,'_3_BlockChainMenu.BlockChain.RicercaUtente(string nome)'],['../class__3___block_chain_menu_1_1_block_chain.html#ac08bea4dc3b79e5e64a6119a993541cd',1,'_3_BlockChainMenu.BlockChain.RicercaUtente(int? idUtente)']]]
];
