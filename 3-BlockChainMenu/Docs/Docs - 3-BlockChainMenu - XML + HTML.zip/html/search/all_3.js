var searchData=
[
  ['ca',['Ca',['../class__3___block_chain_menu_1_1_ca.html',1,'_3_BlockChainMenu']]],
  ['calcolahash',['CalcolaHash',['../class__3___block_chain_menu_1_1_blocco.html#a24967358a856213c4c74e0ec27685a0e',1,'_3_BlockChainMenu::Blocco']]],
  ['candidati',['Candidati',['../class__3___block_chain_menu_1_1_candidati.html',1,'_3_BlockChainMenu']]],
  ['candidatijson',['CandidatiJson',['../class__3___block_chain_menu_1_1_candidati_json.html',1,'_3_BlockChainMenu']]],
  ['clause',['Clause',['../class__3___block_chain_menu_1_1_smart_contract_1_1_clause.html',1,'_3_BlockChainMenu::SmartContract']]],
  ['contrattojson',['ContrattoJson',['../class__3___block_chain_menu_1_1_smart_contract_1_1_contratto_json.html',1,'_3_BlockChainMenu::SmartContract']]],
  ['creabloccoiniziale',['CreaBloccoIniziale',['../class__3___block_chain_menu_1_1_block_chain.html#a35f9e42dd9d6bd0198abf89b7b737acf',1,'_3_BlockChainMenu::BlockChain']]],
  ['creaportafogli',['CreaPortafogli',['../class__3___block_chain_menu_1_1_utente.html#a7925b5a7ac61585d764e6fa439d932d0',1,'_3_BlockChainMenu::Utente']]]
];
