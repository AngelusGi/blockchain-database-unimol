var searchData=
[
  ['isvalido',['IsValido',['../class__3___block_chain_menu_1_1_block_chain.html#afea654e85bd242c1d8a38596a66ca4da',1,'_3_BlockChainMenu::BlockChain']]]
];
