var searchData=
[
  ['transazioniinattesa',['TransazioniInAttesa',['../class__3___block_chain_menu_1_1_block_chain.html#a404fd655b21a03a3d17221804d3aaa2a',1,'_3_BlockChainMenu::BlockChain']]]
];
