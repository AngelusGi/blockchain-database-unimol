var searchData=
[
  ['dataora',['DataOra',['../class__3___block_chain_menu_1_1_blocco.html#af9a8e0a3243b69f0268bb5e200d6d69d',1,'_3_BlockChainMenu::Blocco']]],
  ['difficoltà',['Difficoltà',['../class__3___block_chain_menu_1_1_block_chain.html#a31303b2253c8ce939d40048d6f656478',1,'_3_BlockChainMenu::BlockChain']]]
];
