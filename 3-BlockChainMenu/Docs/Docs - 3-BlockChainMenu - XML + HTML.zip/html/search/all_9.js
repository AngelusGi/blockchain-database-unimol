var searchData=
[
  ['nome',['Nome',['../class__3___block_chain_menu_1_1_utente.html#abe0b3897d9b76130aadf2bd97ca805e8',1,'_3_BlockChainMenu::Utente']]]
];
