var searchData=
[
  ['hashbloccocorrente',['HashBloccoCorrente',['../class__3___block_chain_menu_1_1_blocco.html#ad025dc2b3a9130e4cd50a7ff10d5c585',1,'_3_BlockChainMenu::Blocco']]],
  ['hashprecedente',['HashPrecedente',['../class__3___block_chain_menu_1_1_blocco.html#a01606c3d4a1d1917c2879f5d0aa17afc',1,'_3_BlockChainMenu::Blocco']]]
];
