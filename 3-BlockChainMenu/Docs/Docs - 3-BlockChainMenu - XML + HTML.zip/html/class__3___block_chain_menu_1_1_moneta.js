var class__3___block_chain_menu_1_1_moneta =
[
    [ "Moneta", "class__3___block_chain_menu_1_1_moneta.html#a5fdd7ebe40d727746a590d351f534207", null ],
    [ "TrasferisciMoneta", "class__3___block_chain_menu_1_1_moneta.html#a4f7b5335eca94f3af1c24dd2f6a98385", null ],
    [ "IdAttualeProprietario", "class__3___block_chain_menu_1_1_moneta.html#a47618594b97866246b03a92999e2ba8f", null ],
    [ "IdMoneta", "class__3___block_chain_menu_1_1_moneta.html#a7f16c915c288cf12c0cc9ad599b7979e", null ],
    [ "IdVecchioProprietario", "class__3___block_chain_menu_1_1_moneta.html#a8f564569ab0827f0b9f163f490528ca8", null ]
];