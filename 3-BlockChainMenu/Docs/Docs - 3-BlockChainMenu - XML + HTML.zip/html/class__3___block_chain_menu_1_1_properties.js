var class__3___block_chain_menu_1_1_properties =
[
    [ "Agv", "class__3___block_chain_menu_1_1_properties.html#a583dd51f10784d6073d420df4898463d", null ],
    [ "Ca", "class__3___block_chain_menu_1_1_properties.html#a9cb5950b98d860d66f828da2cadc85b9", null ],
    [ "Gm", "class__3___block_chain_menu_1_1_properties.html#a05ce3467f71fd8c0c008579e45a68350", null ],
    [ "Professor", "class__3___block_chain_menu_1_1_properties.html#a7effc5ed68e7f48a8b9d8a4987f1c3b4", null ]
];