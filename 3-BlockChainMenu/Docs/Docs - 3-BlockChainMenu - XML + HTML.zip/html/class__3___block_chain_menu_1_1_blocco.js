var class__3___block_chain_menu_1_1_blocco =
[
    [ "Blocco", "class__3___block_chain_menu_1_1_blocco.html#a100e96cfddd905770bb67b9cdc13b6ad", null ],
    [ "CalcolaHash", "class__3___block_chain_menu_1_1_blocco.html#a24967358a856213c4c74e0ec27685a0e", null ],
    [ "Mina", "class__3___block_chain_menu_1_1_blocco.html#ab40348816acbbe4b2e7197eab6c700f4", null ],
    [ "DataOra", "class__3___block_chain_menu_1_1_blocco.html#af9a8e0a3243b69f0268bb5e200d6d69d", null ],
    [ "HashBloccoCorrente", "class__3___block_chain_menu_1_1_blocco.html#ad025dc2b3a9130e4cd50a7ff10d5c585", null ],
    [ "HashPrecedente", "class__3___block_chain_menu_1_1_blocco.html#a01606c3d4a1d1917c2879f5d0aa17afc", null ],
    [ "Indice", "class__3___block_chain_menu_1_1_blocco.html#ad00aa9549d4ad8b15c7f407df46274d8", null ],
    [ "Nonce", "class__3___block_chain_menu_1_1_blocco.html#ad3232138a530977bc030e4f4ec2d1267", null ],
    [ "Transazioni", "class__3___block_chain_menu_1_1_blocco.html#af6b6d03c5f1773c8f4a02a9692096e81", null ]
];